var searchData=
[
  ['initialiser_5fothellier_47',['initialiser_othellier',['../library_8c.html#afc15ba61edbba3d9658461f066f780ed',1,'initialiser_othellier(int othellier[N][N]):&#160;library.c'],['../library_8h.html#afc15ba61edbba3d9658461f066f780ed',1,'initialiser_othellier(int othellier[N][N]):&#160;library.c']]]
];
