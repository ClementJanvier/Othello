var searchData=
[
  ['peux_5fjouer_51',['peux_jouer',['../library_8c.html#ad762fce8ab745c25f0e78c23d6b36c76',1,'peux_jouer(int othellier[N][N], joueur *X):&#160;library.c'],['../library_8h.html#ad762fce8ab745c25f0e78c23d6b36c76',1,'peux_jouer(int othellier[N][N], joueur *X):&#160;library.c']]]
];
