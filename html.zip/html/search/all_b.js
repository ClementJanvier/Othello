var searchData=
[
  ['retourne_28',['retourne',['../library_8c.html#abbb052913b18e1870ce79b3481ba1769',1,'retourne(int othellier[N][N], joueur *X, pion *pion_1):&#160;library.c'],['../library_8h.html#abbb052913b18e1870ce79b3481ba1769',1,'retourne(int othellier[N][N], joueur *X, pion *pion_1):&#160;library.c']]]
];
