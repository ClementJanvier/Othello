var searchData=
[
  ['choix_5fcote_5',['choix_cote',['../library_8c.html#a0c4c3d56ac1c4fc6ab3ca9b1bf8fbafa',1,'choix_cote(joueur *A, joueur *B):&#160;library.c'],['../library_8h.html#a0c4c3d56ac1c4fc6ab3ca9b1bf8fbafa',1,'choix_cote(joueur *A, joueur *B):&#160;library.c']]],
  ['choix_5fcoup_6',['choix_coup',['../library_8c.html#adb311e6950b34079649bf51d79298a67',1,'choix_coup(int othellier[N][N], pion *pion_1, int TabX[], int TabY[], int nb_coup):&#160;library.c'],['../library_8h.html#adb311e6950b34079649bf51d79298a67',1,'choix_coup(int othellier[N][N], pion *pion_1, int TabX[], int TabY[], int nb_coup):&#160;library.c']]],
  ['choix_5fpseudo_7',['choix_pseudo',['../library_8c.html#a1ca7d89159217c0e9c4826a3ab737b80',1,'choix_pseudo(joueur *A, joueur *B):&#160;library.c'],['../library_8h.html#a1ca7d89159217c0e9c4826a3ab737b80',1,'choix_pseudo(joueur *A, joueur *B):&#160;library.c']]],
  ['compte_5fpion_8',['compte_pion',['../library_8c.html#a0dd90dbbd99f13409afd5c01c344621d',1,'compte_pion(int othellier[N][N], joueur *A, joueur *B):&#160;library.c'],['../library_8h.html#a0dd90dbbd99f13409afd5c01c344621d',1,'compte_pion(int othellier[N][N], joueur *A, joueur *B):&#160;library.c']]],
  ['config_5fothellier_9',['config_othellier',['../library_8c.html#abf3dd28e792a7a494cd7d07f145e845b',1,'config_othellier(int othellier[N][N]):&#160;library.c'],['../library_8h.html#abf3dd28e792a7a494cd7d07f145e845b',1,'config_othellier(int othellier[N][N]):&#160;library.c']]],
  ['couleur_5fj_10',['couleur_j',['../structjoueur__s.html#adffa41fdcc8ba43ae18bbb5a7d4ceb7a',1,'joueur_s']]]
];
