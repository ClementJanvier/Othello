var searchData=
[
  ['nb_5fpions_55',['nb_pions',['../structjoueur__s.html#ac6e0cf228d514685ddc28b2e8cbdaeec',1,'joueur_s']]]
];
