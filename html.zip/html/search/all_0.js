var searchData=
[
  ['affichage_5fcoup_0',['affichage_coup',['../library_8c.html#acb02f5cc279bec1b374d777d2cd746c5',1,'affichage_coup(int othellier[N][N], joueur *X, pion *pion_1):&#160;library.c'],['../library_8h.html#acb02f5cc279bec1b374d777d2cd746c5',1,'affichage_coup(int othellier[N][N], joueur *X, pion *pion_1):&#160;library.c']]],
  ['affichage_5fmenu_1',['affichage_menu',['../library_8c.html#a009677fc254c9ef45fc905b0e70ca397',1,'affichage_menu():&#160;library.c'],['../library_8h.html#a009677fc254c9ef45fc905b0e70ca397',1,'affichage_menu():&#160;library.c']]],
  ['affiche_5fnb_5fpions_2',['affiche_nb_pions',['../library_8c.html#abdd9f23113e221126505972e2da78d06',1,'affiche_nb_pions(joueur *A, joueur *B):&#160;library.c'],['../library_8h.html#abdd9f23113e221126505972e2da78d06',1,'affiche_nb_pions(joueur *A, joueur *B):&#160;library.c']]],
  ['afficher_5fothellier_3',['afficher_othellier',['../library_8c.html#a149b6cb7ab78769f620464b984ec8046',1,'afficher_othellier(int othellier[N][N]):&#160;library.c'],['../library_8h.html#a149b6cb7ab78769f620464b984ec8046',1,'afficher_othellier(int othellier[N][N]):&#160;library.c']]]
];
