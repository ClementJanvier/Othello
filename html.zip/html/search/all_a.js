var searchData=
[
  ['peux_5fjouer_24',['peux_jouer',['../library_8c.html#ad762fce8ab745c25f0e78c23d6b36c76',1,'peux_jouer(int othellier[N][N], joueur *X):&#160;library.c'],['../library_8h.html#ad762fce8ab745c25f0e78c23d6b36c76',1,'peux_jouer(int othellier[N][N], joueur *X):&#160;library.c']]],
  ['pion_5fs_25',['pion_s',['../structpion__s.html',1,'']]],
  ['posx_26',['PosX',['../structpion__s.html#a6dc0951edc2dd91ad8a8d6143aac8f97',1,'pion_s']]],
  ['posy_27',['PosY',['../structpion__s.html#abdd0c2adadce22348242c9f73f6a8109',1,'pion_s']]]
];
