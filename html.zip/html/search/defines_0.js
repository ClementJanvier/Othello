var searchData=
[
  ['blanc_58',['BLANC',['../library_8h.html#a4371941fa5aa27c04b3e2b973c39f4b0',1,'library.h']]]
];
